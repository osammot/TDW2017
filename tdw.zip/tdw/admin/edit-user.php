<?php
            
require("../include/dbms.inc.php");
require("../include/template2.inc.php");


if ($db->isConnected()) {
   
$x =$_POST['selezione'];   
$id =$_POST['id_utente'];
$u =$_POST['user'];
$p =$_POST['password'];
$e =$_POST['emial'];
    
   
$db->query("UPDATE utenti 
            SET id_utente = '{$id}', user='{$u}', password = '{$p}', email = '{$e}' WHERE user = '{$x}' ");
    
}

$main = new Template("index.html");
$categoria = new Template("edit-user.html");


$db->query("SELECT * FROM utenti");
             
         $row = $db->getResult();
                               
                 foreach($row as $rows) {

                    $categoria->setContent($rows);
                
                 } //end foreach

 
$main->setContent("content",$categoria->get());
$main->close();

?>