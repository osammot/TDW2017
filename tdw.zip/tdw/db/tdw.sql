-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Creato il: Mag 22, 2017 alle 16:02
-- Versione del server: 5.6.33
-- Versione PHP: 5.6.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `tdw017`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `anagrafica`
--

CREATE TABLE `anagrafica` (
  `id_anagrafica` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `cognome` varchar(50) DEFAULT NULL,
  `indirizzo` varchar(100) DEFAULT NULL,
  `citta` varchar(50) DEFAULT NULL,
  `CAP` int(11) DEFAULT NULL,
  `stato` varchar(50) DEFAULT NULL,
  `cellulare` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `carrello`
--

CREATE TABLE `carrello` (
  `id_sessione` int(11) NOT NULL,
  `quantita` int(11) DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `categorie`
--

CREATE TABLE `categorie` (
  `id_categoria` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `descrizione` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `categorie`
--

INSERT INTO `categorie` (`id_categoria`, `nome`, `descrizione`) VALUES
(0, '', ''),
(1, 'Avventura', ''),
(2, 'horror', 'ssss'),
(3, 'dramma', 'hays'),
(5, 'fantasy', '');

-- --------------------------------------------------------

--
-- Struttura della tabella `dettagli_ordine`
--

CREATE TABLE `dettagli_ordine` (
  `id_dettaglio` int(11) NOT NULL,
  `numero_articoli` int(11) DEFAULT NULL,
  `id_ordine` int(11) DEFAULT NULL,
  `id_prodotto` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `galleria_immagini`
--

CREATE TABLE `galleria_immagini` (
  `id_immagine` int(11) NOT NULL,
  `path` varchar(50) DEFAULT NULL,
  `id_prodotto` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `galleria_immagini`
--

INSERT INTO `galleria_immagini` (`id_immagine`, `path`, `id_prodotto`) VALUES
(1, './img/film7.jpg', 1),
(2, './img/film6.jpg', 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `gruppi`
--

CREATE TABLE `gruppi` (
  `id_gruppo` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `descrizione` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `gruppi`
--

INSERT INTO `gruppi` (`id_gruppo`, `nome`, `descrizione`) VALUES
(0, '', ''),
(1, 'admin', 'dddd');

-- --------------------------------------------------------

--
-- Struttura della tabella `gruppiservizi`
--

CREATE TABLE `gruppiservizi` (
  `id_servizio` int(11) DEFAULT NULL,
  `id_gruppo` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `gruppiservizi`
--

INSERT INTO `gruppiservizi` (`id_servizio`, `id_gruppo`) VALUES
(1, 1),
(2, 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `news`
--

CREATE TABLE `news` (
  `id_news` int(11) NOT NULL,
  `data_news` date DEFAULT NULL,
  `immagine` varchar(1000) NOT NULL,
  `titolo` varchar(50) DEFAULT NULL,
  `corpo` longtext NOT NULL,
  `id_prodotto` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `news`
--

INSERT INTO `news` (`id_news`, `data_news`, `immagine`, `titolo`, `corpo`, `id_prodotto`) VALUES
(1, '2016-12-11', './img/serie1.jpg', 'UFFICIALE - LOS POLLOS', 'Netflix ha annunciato che anche in Italia, dopo il successo in Usa, aprirà la catena di fast food "Los Pollos Hermanos", il famoso ristorante per famiglie tanto amato dai fan di Breaking Bad, la serie creta da Vince Gilligan. Le città italiane scelte dal colosso streaming per l\'apertura straordinaria del 12 e 13 maggio sono Roma e Milano. Un\'apertura che coincide con l\'uscita della terza stagione di Better Call Saul, spin-off della serie principale che ha per protagonisti Walter White, Jesse Pinkman e il re del pollo fritto, ma in realtà spietato trafficante di droga, Gustavo "Gus" Fring.\r\n\r\n"È con immenso piacere - scrive Neflix sui social - che annunciamo l\'apertura dell\'autentico Los Pollos Hermanos anche in Italia. Vieni a provare il gusto stupefacente del nostro pollo fritto, preparato con amore e servito con il sorriso dal nostro personale, che sarà a tua disposizione per garantire un\'esperienza impeccabile.\r\n\r\nTi aspettiamo il 12 e il 13 maggio, in Piazza XXIV maggio, 4 (Milano) e in Via Cavour 333/335 (Roma)\r\n\r\nIn omaggio per te pollo fritto, curly fries e bibita, dalle 18:30.\r\n\r\nPuoi parlare con il proprietario del ristorante, chiamando il 342 0305572. Non esitare a contattarlo!"\r\n\r\nE chiamando il numero, si scopre che a fornire i dettagli delle due aperture è proprio la voce pacata e tranquilla del mitico Gus, che invita i fan, ma non solo, a recarsi presso i locali per provare il "gusto stupefacente" dei suoi prodotti e di non preoccuparsi nel caso in cui dovessero avere qualche problema, perché "provvederà personalmente a sistemare la faccenda". Simpatici doppi sensi che si legano all\'ambigua figura del personaggio interpretato dall\'attore Giancarlo Esposito.', 5),
(2, '2016-05-20', './img/film1.jpg', 'American Sniper', 'Afghanistan. Una pattuglia delle Forze Speciali è impegnata nel tentativo di liberare un senatore americano le cui guardie del corpo private sono state tutte uccise. L\'impresa riesce ma due soldati (tra cui un valente cecchino) debbono essere lasciati indietro. La priorità spetta però non al loro recupero ma a quello di un camion carico di esplosivi che è finito in panne in una zona in cui c\'è il pericolo di un agguato.\nSuperato il dubbio sul partner di Seagal (non è Van Damme bensì Van Dam, wrestler e attore) si deve superare un pregiudizio. Da molti anni è difficile trovare un film che abbia come protagonista l\'attore americano che presenti una sceneggiatura valida. In questa occasione invece, pur rimanendo in zona B movie, ci viene proposta una storia che ha dei motivi di interesse.\nIl segreto sta forse nel fatto che Seagal mette il nome sul manifesto (il che serve per far vendere il dvd o il Blu-ray in diverse aree geografico-culturali del mondo) ma poi sta per gran parte del tempo seduto o impegnato a sparare da una postazione fissa. Lascia così spazio agli altri interpreti i quali hanno la fisicità giusta (lui ormai è da tempo in sovrappeso) per le scene di azione.\nPreso atto che siamo sempre in ambito conservatore di destra (il senatore democratico mette a rischio numerose vite perché ha avuto la \'pretesa\' di verificare sul posto se si stanno sprecando risorse economiche in un conflitto inutile) bisogna riconoscere alla regia di Fred Olen Ray una certa dose di coraggio. Perché quasi 18 minuti di un film che dura meno di 90 vengono utilizzati all\'inizio per descrivere il combattimento tra soldati Usa e talebani finalizzato alla liberazione dell\'uomo politico. Questa decisione consente di costruire un clima di tensione notevole e di dare allo spettatore, comodamente seduto in poltrona, la sensazione di stare assistendo a un vero scontro. Anche la scelta di procedere successivamente con un montaggio parallelo contribuisce a tenere desta l\'attenzione sui due versanti della narrazione. Ovviamente la retorica non manca ma, grazie forse anche alla presenza di due personaggi femminili, viene proposta a livelli accettabili.', NULL),
(4, '2017-02-06', './img/serie9.jpg', 'ufficiale ', 'ddddd', 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `ordini`
--

CREATE TABLE `ordini` (
  `id_ordine` int(11) NOT NULL,
  `data_ordine` date DEFAULT NULL,
  `cellulare_consegna` int(11) DEFAULT NULL,
  `costo_totale` float DEFAULT NULL,
  `indirizzo` varchar(50) DEFAULT NULL,
  `citta` varchar(50) DEFAULT NULL,
  `CAP` int(11) DEFAULT NULL,
  `stato` varchar(50) DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `id_prodotto` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `ordiniprodotti`
--

CREATE TABLE `ordiniprodotti` (
  `id_ordine` int(11) DEFAULT NULL,
  `id_prodotto` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `pagamenti`
--

CREATE TABLE `pagamenti` (
  `id_pagamento` int(11) NOT NULL,
  `importo` int(11) DEFAULT NULL,
  `metodo_pagamento` varchar(50) DEFAULT NULL,
  `data_pagamento` date DEFAULT NULL,
  `id_ordine` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `prodotti`
--

CREATE TABLE `prodotti` (
  `id_prodotto` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `durata` varchar(50) DEFAULT NULL,
  `distribuzione` varchar(50) DEFAULT NULL,
  `formato` varchar(50) DEFAULT NULL,
  `tipologia` varchar(50) DEFAULT NULL,
  `regista` varchar(50) DEFAULT NULL,
  `prezzo` float DEFAULT NULL,
  `quantita_disponibile` int(11) DEFAULT NULL,
  `data_uscita` date DEFAULT NULL,
  `descrizione` text,
  `path` varchar(1000) NOT NULL,
  `id_categoria` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `prodotti`
--

INSERT INTO `prodotti` (`id_prodotto`, `nome`, `durata`, `distribuzione`, `formato`, `tipologia`, `regista`, `prezzo`, `quantita_disponibile`, `data_uscita`, `descrizione`, `path`, `id_categoria`) VALUES
(0, 'Narcos', '180', '', '', 'serie', '', 45.78, 0, '0000-00-00', '', './img/serie8.jpg', 0),
(1, 'Revenant', '180', 'universa', 'dvd', 'film', 'fs', 15, 34, '2016-02-02', 'Revenant - Redivivo (The Revenant) è un film del 2015, diretto, co-scritto e co-prodotto da Alejandro González Iñárritu.[1]\r\n\r\nScritto dallo stesso Iñárritu e da Mark Lee Smith e distribuito dalla 20th Century Fox, è in parte basato sul romanzo Revenant - La storia vera di Hugh Glass e della sua vendetta (2002, edito in Italia da Einaudi nel 2014) di Michael Punke ed è parzialmente ispirato alla vita del cacciatore di pelli Hugh Glass,[2] vissuto a cavallo tra il Settecento e l\'Ottocento e che, nel 1823, durante una spedizione commerciale lungo il Missouri, fu abbandonato in fin di vita dai suoi compagni, riuscendo a sopravvivere. Il soggetto è già stato usato da un\'altra pellicola, Uomo bianco, va\' col tuo dio! (Man in the Wilderness) del 1971, così da poter considerare Revenant un remake dello stesso. La pellicola vede come protagonista Leonardo DiCaprio, affiancato da Tom Hardy, Will Poulter e Domhnall Gleeson.\r\n\r\nIl film ha vinto molti premi: 3 Golden Globes su 4 nomination,[3] 5 premi BAFTA su 9 nomination e 3 Premi Oscar su 12 candidature ottenute, incluso il premio come "Miglior attore protagonista" a Leonardo DiCaprio, che con questo film ottiene la sua prima vittoria agli Oscar.[4]', './img/film5.jpg', 1),
(2, 'Rocky', '180', 'universa', 'dvd', 'film', 'dddd', 100, 4, '1995-02-02', '', './img/film2.jpg', 0),
(4, 'Perfetti Sconosciuti', '120', 'dddd', 'dvd', 'film', 'ddd', 23, 23, '2016-03-02', '', ' ./img/film4.jpg', 0),
(5, 'Breaking Bad', NULL, NULL, NULL, 'serie', NULL, 12, NULL, '2015-05-16', NULL, './img/serie1.jpg', NULL),
(43, 'Fury', '233', 'fff', 'fff', 'film', 'fff', 12, 10, '2017-01-01', '', ' ./img/film8.jpg', 0),
(56, '13 Hours', '122', 'ggg', 'ggg', 'film', 'ggg', 12, NULL, '2014-05-16', NULL, './img/film9.jpg', NULL),
(344, 'House of Cards', '45', NULL, NULL, 'serie', NULL, 76, NULL, '2017-05-24', NULL, './img/serie12.jpg', NULL),
(566, 'Vikings', NULL, NULL, NULL, 'serie', NULL, 100, NULL, '2017-05-26', NULL, './img/serie4.jpg', NULL),
(3232, 'Gomorra', '320', 'Universal', 'dvd', 'serie', 'fff', 12, 34, '2016-09-03', '', ' ./img/serie7.jpg', 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `prodottinews`
--

CREATE TABLE `prodottinews` (
  `id_prodotto` int(11) DEFAULT NULL,
  `id_news` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `recensioni`
--

CREATE TABLE `recensioni` (
  `id_recensione` int(11) NOT NULL,
  `data_recensione` date DEFAULT NULL,
  `recensione` text,
  `titolo` varchar(50) DEFAULT NULL,
  `id_prodotto` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `servizi`
--

CREATE TABLE `servizi` (
  `id_servizio` int(11) NOT NULL,
  `script` varchar(50) DEFAULT NULL,
  `descrizione` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `servizi`
--

INSERT INTO `servizi` (`id_servizio`, `script`, `descrizione`) VALUES
(1, 'login.php', NULL),
(2, 'add-categoria.php', NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `spedizioni`
--

CREATE TABLE `spedizioni` (
  `id_spedizione` int(11) NOT NULL,
  `metodo_spedizione` varchar(50) DEFAULT NULL,
  `data_spedizione` date DEFAULT NULL,
  `id_ordine` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `user` varchar(50) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`user`, `password`, `email`) VALUES
('', '', ''),
('Stefano', 'fffff', 'fffffff@.com');

-- --------------------------------------------------------

--
-- Struttura della tabella `utentigruppi`
--

CREATE TABLE `utentigruppi` (
  `user` varchar(50) DEFAULT NULL,
  `id_gruppo` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `utentigruppi`
--

INSERT INTO `utentigruppi` (`user`, `id_gruppo`) VALUES
('', 0),
('', 1),
('', 0),
('Stefano', 1),
('Stefano', 1),
('', NULL);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `anagrafica`
--
ALTER TABLE `anagrafica`
  ADD PRIMARY KEY (`id_anagrafica`),
  ADD KEY `user` (`user`);

--
-- Indici per le tabelle `carrello`
--
ALTER TABLE `carrello`
  ADD PRIMARY KEY (`id_sessione`),
  ADD KEY `user` (`user`);

--
-- Indici per le tabelle `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Indici per le tabelle `dettagli_ordine`
--
ALTER TABLE `dettagli_ordine`
  ADD PRIMARY KEY (`id_dettaglio`),
  ADD KEY `id_ordine` (`id_ordine`);

--
-- Indici per le tabelle `galleria_immagini`
--
ALTER TABLE `galleria_immagini`
  ADD PRIMARY KEY (`id_immagine`),
  ADD KEY `id_prodotto` (`id_prodotto`);

--
-- Indici per le tabelle `gruppi`
--
ALTER TABLE `gruppi`
  ADD PRIMARY KEY (`id_gruppo`);

--
-- Indici per le tabelle `gruppiservizi`
--
ALTER TABLE `gruppiservizi`
  ADD KEY `id_servizio` (`id_servizio`),
  ADD KEY `id_gruppo` (`id_gruppo`);

--
-- Indici per le tabelle `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id_news`),
  ADD KEY `id_prodotto` (`id_prodotto`);

--
-- Indici per le tabelle `ordini`
--
ALTER TABLE `ordini`
  ADD PRIMARY KEY (`id_ordine`),
  ADD KEY `user` (`user`),
  ADD KEY `id_prodotto` (`id_prodotto`);

--
-- Indici per le tabelle `ordiniprodotti`
--
ALTER TABLE `ordiniprodotti`
  ADD KEY `id_ordine` (`id_ordine`),
  ADD KEY `id_prodotto` (`id_prodotto`);

--
-- Indici per le tabelle `pagamenti`
--
ALTER TABLE `pagamenti`
  ADD PRIMARY KEY (`id_pagamento`),
  ADD KEY `id_ordine` (`id_ordine`);

--
-- Indici per le tabelle `prodotti`
--
ALTER TABLE `prodotti`
  ADD PRIMARY KEY (`id_prodotto`),
  ADD KEY `id_categoria` (`id_categoria`);

--
-- Indici per le tabelle `prodottinews`
--
ALTER TABLE `prodottinews`
  ADD KEY `id_prodotto` (`id_prodotto`),
  ADD KEY `id_news` (`id_news`);

--
-- Indici per le tabelle `recensioni`
--
ALTER TABLE `recensioni`
  ADD PRIMARY KEY (`id_recensione`),
  ADD KEY `id_prodotto` (`id_prodotto`);

--
-- Indici per le tabelle `servizi`
--
ALTER TABLE `servizi`
  ADD PRIMARY KEY (`id_servizio`);

--
-- Indici per le tabelle `spedizioni`
--
ALTER TABLE `spedizioni`
  ADD PRIMARY KEY (`id_spedizione`),
  ADD KEY `id_ordine` (`id_ordine`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`user`);

--
-- Indici per le tabelle `utentigruppi`
--
ALTER TABLE `utentigruppi`
  ADD KEY `user` (`user`),
  ADD KEY `id_gruppo` (`id_gruppo`);

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `anagrafica`
--
ALTER TABLE `anagrafica`
  ADD CONSTRAINT `anagrafica_ibfk_1` FOREIGN KEY (`user`) REFERENCES `utenti` (`user`);

--
-- Limiti per la tabella `carrello`
--
ALTER TABLE `carrello`
  ADD CONSTRAINT `carrello_ibfk_1` FOREIGN KEY (`user`) REFERENCES `utenti` (`user`);

--
-- Limiti per la tabella `dettagli_ordine`
--
ALTER TABLE `dettagli_ordine`
  ADD CONSTRAINT `dettagli_ordine_ibfk_1` FOREIGN KEY (`id_ordine`) REFERENCES `ordini` (`id_ordine`);

--
-- Limiti per la tabella `galleria_immagini`
--
ALTER TABLE `galleria_immagini`
  ADD CONSTRAINT `galleria_immagini_ibfk_1` FOREIGN KEY (`id_prodotto`) REFERENCES `prodotti` (`id_prodotto`);

--
-- Limiti per la tabella `gruppiservizi`
--
ALTER TABLE `gruppiservizi`
  ADD CONSTRAINT `gruppiservizi_ibfk_1` FOREIGN KEY (`id_servizio`) REFERENCES `servizi` (`id_servizio`),
  ADD CONSTRAINT `gruppiservizi_ibfk_2` FOREIGN KEY (`id_gruppo`) REFERENCES `gruppi` (`id_gruppo`);

--
-- Limiti per la tabella `news`
--
ALTER TABLE `news`
  ADD CONSTRAINT `news_ibfk_1` FOREIGN KEY (`id_prodotto`) REFERENCES `prodotti` (`id_prodotto`);

--
-- Limiti per la tabella `ordini`
--
ALTER TABLE `ordini`
  ADD CONSTRAINT `ordini_ibfk_1` FOREIGN KEY (`user`) REFERENCES `utenti` (`user`),
  ADD CONSTRAINT `ordini_ibfk_2` FOREIGN KEY (`id_prodotto`) REFERENCES `prodotti` (`id_prodotto`);

--
-- Limiti per la tabella `ordiniprodotti`
--
ALTER TABLE `ordiniprodotti`
  ADD CONSTRAINT `ordiniprodotti_ibfk_1` FOREIGN KEY (`id_ordine`) REFERENCES `ordini` (`id_ordine`),
  ADD CONSTRAINT `ordiniprodotti_ibfk_2` FOREIGN KEY (`id_prodotto`) REFERENCES `prodotti` (`id_prodotto`);

--
-- Limiti per la tabella `pagamenti`
--
ALTER TABLE `pagamenti`
  ADD CONSTRAINT `pagamenti_ibfk_1` FOREIGN KEY (`id_ordine`) REFERENCES `ordini` (`id_ordine`);

--
-- Limiti per la tabella `prodotti`
--
ALTER TABLE `prodotti`
  ADD CONSTRAINT `prodotti_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categorie` (`id_categoria`);

--
-- Limiti per la tabella `prodottinews`
--
ALTER TABLE `prodottinews`
  ADD CONSTRAINT `prodottinews_ibfk_1` FOREIGN KEY (`id_prodotto`) REFERENCES `prodotti` (`id_prodotto`),
  ADD CONSTRAINT `prodottinews_ibfk_2` FOREIGN KEY (`id_news`) REFERENCES `news` (`id_news`);

--
-- Limiti per la tabella `recensioni`
--
ALTER TABLE `recensioni`
  ADD CONSTRAINT `recensioni_ibfk_1` FOREIGN KEY (`id_prodotto`) REFERENCES `prodotti` (`id_prodotto`);

--
-- Limiti per la tabella `spedizioni`
--
ALTER TABLE `spedizioni`
  ADD CONSTRAINT `spedizioni_ibfk_1` FOREIGN KEY (`id_ordine`) REFERENCES `ordini` (`id_ordine`);

--
-- Limiti per la tabella `utentigruppi`
--
ALTER TABLE `utentigruppi`
  ADD CONSTRAINT `utentigruppi_ibfk_1` FOREIGN KEY (`user`) REFERENCES `utenti` (`user`),
  ADD CONSTRAINT `utentigruppi_ibfk_2` FOREIGN KEY (`id_gruppo`) REFERENCES `gruppi` (`id_gruppo`);
