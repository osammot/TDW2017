<?php
            
require("../include/dbms.inc.php");
require("../include/template2.inc.php");


if ($db->isConnected()) {
   
$x =$_POST['selezione'];   
$id =$_POST['id_servizio'];
$scr =$_POST['script'];
$desc =$_POST['descrizione'];
    
   
$db->query("UPDATE servizi 
            SET id_servizio = '{$id}', script='{$scr}', descrizione = '{$desc}' WHERE script = '{$x}' ");
    
}

$main = new Template("index.html");
$categoria = new Template("edit-servizio.html");


$db->query("SELECT * FROM servizi");
             
         $row = $db->getResult();
                               
                 foreach($row as $rows) {

                    $categoria->setContent($rows);
                
                 } //end foreach

 
$main->setContent("content",$categoria->get());
$main->close();

?>