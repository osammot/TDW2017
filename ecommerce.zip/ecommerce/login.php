<?php


require("include/dbms.inc.php");
require("include/template2.inc.php");
require("include/auth.inc.php");

Header("Location: index.php");



?>

