<?php

require("include/dbms.inc.php");
require("include/template2.inc.php");

$main = new Template("login.html");

$main->close();
?>
