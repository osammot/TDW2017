<?php

require("include/dbms.inc.php");
require("include/template2.inc.php");


$main = new Template("frame-public.html");
$menu = new Template("menu.html");
$body = new Template("single-product.html");

$db->query("SELECT nome FROM categorie");
        
        $roww = $db->getResult();
                               
                 foreach($roww as $rowsw) {
                     $var = $rowsw['nome'];

                    $menu->setContent("nome",$var);
                
                 } //end foreach

$db->query("SELECT nome, prezzo, path FROM prodotti LIMIT 4");
        
        $row1 = $db->getResult();
                               
                 foreach($row1 as $rows1) {
                     $varpath = $rows1['path'];
                     $varnome = $rows1['nome'];
                     $varprezzo = $rows1['prezzo'];
                     

                     $body->setContent("paths",$varpath);
                     $body->setContent("nomes",$varnome);
                     $body->setContent("prezzos",$varprezzo);
                
                 } //end foreach

$db->query("SELECT nome, prezzo, path, descrizione FROM prodotti WHERE id_prodotto=1");
        
        $row2 = $db->getResult();
                               
                 foreach($row2 as $rows2) {
                     $varpath1 = $rows2['path'];
                     $varnome1 = $rows2['nome'];
                     $varprezzo1 = $rows2['prezzo'];
                     $vardesc1 = $rows2['descrizione'];
                     

                     $body->setContent("pathc",$varpath1);
                     $body->setContent("nomec",$varnome1);
                     $body->setContent("prezzoc",$varprezzo1);
                     $body->setContent("descrizionec",$vardesc1);
                
                 } //end foreach

$db->query("SELECT path FROM galleria_immagini WHERE id_prodotto=1");
        
        $row3 = $db->getResult();
                               
                 foreach($row3 as $rows3) {
                     $varpath2 = $rows3['path'];
                    
                  $body->setContent("piupath",$varpath2);
                
                 } //end foreach




$main->setContent("menu",$menu->get());
$main->setContent("body",$body->get());
$main->close();


?>