<?php

require("include/dbms.inc.php");
require("include/template2.inc.php");


$main = new Template("frame-public.html");
$menu = new Template("menu.html");
$body = new Template("news.html");

$db->query("SELECT nome FROM categorie");
        
        $roww = $db->getResult();
                               
                 foreach($roww as $rowsw) {
                     $var = $rowsw['nome'];
                     $menu->setContent("nome",$var);
                
                 } //end foreach

$db->query("SELECT data_news, immagine, titolo, corpo FROM news ORDER BY data_news DESC LIMIT 3 ");
        
        $row1 = $db->getResult();
                               
                 foreach($row1 as $rows1) {
                     $vardata = $rows1['data_news'];
                     $varnome = $rows1['immagine'];
                     $varprezzo = $rows1['titolo'];
                     $varpath = $rows1['corpo'];
                     

                     $body->setContent("data_news",$vardata);
                     $body->setContent("immagine",$varnome);
                     $body->setContent("titolo",$varprezzo);
                     $body->setContent("corpo",$varpath);
                
                 } //end foreach



$main->setContent("menu",$menu->get());
$main->setContent("body",$body->get());
$main->close();


?>