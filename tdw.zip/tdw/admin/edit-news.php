<?php

require("../include/dbms.inc.php");
require("../include/template2.inc.php");


if ($db->isConnected()) {
    
$x =$_POST['selezione'];
$y =$_POST['id_news'];
$z =$_POST['data'];
$r =$_POST['titolo'];
$s =$_POST['selezione2'];


$db->query("UPDATE news SET data_news='{$z}', id_news= '{$y}', titolo= '{$r}', id_prodotto='{$s}' WHERE data_news = '{$x}' ");
   
        
}

$main = new Template("index.html");
$categoria = new Template("edit-news.html");

$db->query("SELECT * FROM news");
             
         $row = $db->getResult();
                               
                 foreach($row as $rows) {

                    $categoria->setContent($rows);
 
                 }

$db->query("SELECT * FROM prodotti");
             
         $row = $db->getResult();
                               
                 foreach($row as $rows) {

                    $categoria->setContent($rows);
 
                 }

$main->setContent("content",$categoria->get());
$main->close();


?>