<?php

require("../include/dbms.inc.php");
require("../include/template2.inc.php");

$x =$_POST['selezione'];
$y =$_POST['id_categoria'];
$z =$_POST['nome'];
$r =$_POST['descrizione'];


$db->query("UPDATE categorie SET nome='{$z}', id_categoria = '{$y}', descrizione= '{$r}' WHERE nome = '{$x}' ");

?>