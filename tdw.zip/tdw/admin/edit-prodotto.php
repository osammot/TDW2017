<?php

require("../include/dbms.inc.php");
require("../include/template2.inc.php");



if ($db->isConnected()) {   
   
$sel =$_POST['selezione'];
    
$id =$_POST['id_prodotto'];
$nome =$_POST['nome'];
$durata =$_POST['durata'];
$distr =$_POST['distribuzione'];
$form =$_POST['formato'];
$tipo =$_POST['tipologia'];
$reg =$_POST['regista'];
$prez =$_POST['prezzo'];
$quant =$_POST['quantita_disponibile'];
$dat =$_POST['data_uscita'];
$desc =$_POST['descrizione'];
$s =$_POST['selezione2'];
    
   
$db->query("UPDATE prodotti 
            SET 
             id_prodotto = '{$id}', 
             nome='{$nome}', 
             durata = '{$durata}', 
             distribuzione= '{$distr}', 
             formato= '{$form}', 
             tipologia='{$tipo}', 
             regista = '{$reg}', 
             prezzo = '{$prez}', 
             quantita_disponibile = '{$quant}', 
             data_uscita = '{$dat}', 
             descrizione = '{$desc}',
             id_categoria ='{$s}'
            WHERE nome = '{$sel}' 
            ");
   
   // UPDATE `prodotti` SET `id_prodotto`=[value-1],`nome`=[value-2],`durata`=[value-3],`distribuzione`=[value-4],`formato`=[value-5],`tipologia`=[value-6],`regista`=[value-7],`prezzo`=[value-8],`quantita_disponibile`=[value-9],`data_uscita`=[value-10],`descrizione`=[value-11],`id_categoria`=[value-12] WHERE 1
        
}

$main = new Template("index.html");
$categoria = new Template("edit-prodotto.html");

$db->query("SELECT * FROM prodotti");
             
         $row = $db->getResult();
                               
                 foreach($row as $rows) {

                    $categoria->setContent($rows);
 
                 }

$db->query("SELECT * FROM categorie");
             
         $roww = $db->getResult();
                               
                 foreach($roww as $rowss) {

                    $categoria->setContent($rowss);
 
                 }

$main->setContent("content",$categoria->get());
$main->close();


?>