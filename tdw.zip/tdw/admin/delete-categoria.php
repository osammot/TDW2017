<?php
            
require("../include/dbms.inc.php");
require("../include/template2.inc.php");


$x =$_POST['selezione'];

//echo $x ;

if ($db->isConnected()) {
    
$db->query("DELETE FROM categorie WHERE nome = '{$x}'  ");
    
}

$main = new Template("index.html");
$categoria = new Template("delete-categoria.html");


$db->query("SELECT nome AS nome FROM categorie");
             
         $row = $db->getResult();
                               
                 foreach($row as $rows) {

                    $categoria->setContent($rows);
                
                 } //end foreach

 
$main->setContent("content",$categoria->get());
$main->close();

?>