<?php

require("../include/dbms.inc.php");
require("../include/template2.inc.php");

$x =$_POST['nomeuser'];

$db->query("SELECT id_utente, user, password, email  
            FROM utenti WHERE user = '{$x}' ");

$row = $db->getResult();

if($row!=false){
    echo json_encode($row[0]);  //per restituire al js la riga restiuita dalla query
}

?>