<?php

require("../include/dbms.inc.php");
require("../include/template2.inc.php");


$main = new Template("index.html");
$categoria = new Template("edit-immagini.html");


$main->setContent("content",$categoria->get());
$main->close();


?>