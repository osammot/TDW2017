//funzioni js per validare campi vuoti
function validateFormCategoria(){
        var x = document.forms["myForm"]["id_categoria"].value;
        var y = document.forms["myForm"]["nome"].value;

    if (x == "" || y == "") {
        alert("Attenzione, ci sono dei campi vuoti oppure i dati inseriri non rispettano i tipi assegnati!");
        return false;
    }
}

function validateFormGroup(){
        var x = document.forms["myForm"]["id_gruppo"].value;
        var y = document.forms["myForm"]["nome"].value;
        var z = document.forms["myForm"]["descrizione"].value;

    if (x == "" || y == "" || z == "") {
        alert("Attenzione, ci sono dei campi vuoti oppure i dati inseriri non rispettano i tipi assegnati!");
        return false;
    }
}

function validateFormServizio(){
        var x = document.forms["myForm"]["id_servizio"].value;
        var y = document.forms["myForm"]["script"].value;
        var z = document.forms["myForm"]["descrizione"].value;

    if (x == "" || y == "" || z == "") {
        alert("Attenzione, ci sono dei campi vuoti oppure i dati inseriri non rispettano i tipi assegnati!");
        return false;
    }
}

function validateFormUser(){
        var y = document.forms["myForm"]["user"].value;
        var z = document.forms["myForm"]["password"].value;
        var w = document.forms["myForm"]["email"].value;

    if (y == "" || z == "" || w == "") {
        alert("Attenzione, ci sono dei campi vuoti oppure i dati inseriri non rispettano i tipi assegnati!");
        return false;
    }
}

function validateFormNews(){
        var x = document.forms["myForm"]["id_news"].value;
        var y = document.forms["myForm"]["data_news"].value;
        var z = document.forms["myForm"]["titolo"].value;
      //  var w = document.forms["myForm"]["id_prodotto"].value;

    if (x == "" || y == "" || z == "" ) {
        alert("Attenzione, ci sono dei campi vuoti oppure i dati inseriri non rispettano i tipi assegnati!");
        return false;
    }
}

 function validateFormProdotti(){
        var x = document.forms["myForm"]["id_prodotto"].value;
        var y = document.forms["myForm"]["nome"].value;
        var p = document.forms["myForm"]["durata"].value;
        var r = document.forms["myForm"]["tipologia"].value;
        var w = document.forms["myForm"]["prezzo"].value;
        var z = document.forms["myForm"]["quantita_disp"].value;
        var s = document.forms["myForm"]["id_categoria"].value;
        var t = document.forms["myForm"]["data_uscita"].value;
        
        
    if (x == "" || y == "" || p == "" || r == "" || w == "" || z == "" || s == "" || t == "" ) {
        alert("Attenzione, ci sono dei campi vuoti oppure i dati inseriri non rispettano i tipi assegnati!");
        return false;
    }
}





//funzioni jquery per la modifica di elementi 
function editcategoria(){    
        //e.preventDefault(); //blocca il submit
        
        var nomecategoria = $("#nomecategoria option:selected").text(); //recupera testo dentro l'opzione selezionata
        var nomecategoria = $.trim(nomecategoria); //rimuove spazi prima e dopo
        $.ajax({
            
            type:"POST",
            url:"edit-categoria-click.php",
            data:{ nomecategoria:nomecategoria }, //se sono più dati, separati da virgole (sx=php, dx=js)
            success: function(response){
                var result = JSON.parse(response);  //recuperare ciò che restituisce il php e interpretarlo
                //alert(result.id_categoria);  //accedi al campo desiderato
                $('#id').val(result.id_categoria);
                $('#noome').val(result.nome); //sx: id input dx: nome database
                $('#desc').val(result.descrizione);
                $(".mod").css({'visibility':'visible'});
            },
            error: function(response){
                alert(response);
            }
            
        });
}



function editnews(){    
        //e.preventDefault(); //blocca il submit
        
        var nomenews = $("#nomenews option:selected").text(); //recupera testo dentro l'opzione selezionata
        var nomenews = $.trim(nomenews); //rimuove spazi prima e dopo
        $.ajax({
            
            type:"POST",
            url:"edit-news-click.php",
            data:{ nomenews:nomenews }, //se sono più dati, separati da virgole (sx=php, dx=js)
            success: function(response){
                var result = JSON.parse(response);  //recuperare ciò che restituisce il php e interpretarlo
                //alert(result.id_categoria);  //accedi al campo desiderato
                $('#id').val(result.id_news);
                $('#daata').val(result.data_news); //sx: id input dx: nome database
                $('#titoolo').val(result.titolo);
                $('#id_prodotto').val(result.id_prodotto);
                $(".mod").css({'visibility':'visible'});
            },
            error: function(response){
                alert(response);
            }
            
        });
}


function editprodotto(){    
        
        var nomeprodotto = $("#nomeprodotto option:selected").text(); //recupera testo dentro l'opzione selezionata
        var nomeprodotto = $.trim(nomeprodotto); //rimuove spazi prima e dopo
        $.ajax({
            
            type:"POST",
            url:"edit-prodotto-click.php",
            data:{ nomeprodotto:nomeprodotto }, //se sono più dati, separati da virgole (sx=php, dx=js)
            success: function(response){
                var result = JSON.parse(response);  //recuperare ciò che restituisce il php e interpretarlo
                //alert(result.id_categoria);  //accedi al campo desiderato
                $('#id').val(result.id_prodotto);
                $('#noome').val(result.nome);
                $('#duraata').val(result.durata);
                $('#distr').val(result.distribuzione);
                $('#formaato').val(result.formato);
                $('#tipoologia').val(result.tipologia);
                $('#registaa').val(result.regista);
                $('#preezzo').val(result.prezzo);
                $('#quant').val(result.quantita_disponibile);
                $('#data').val(result.data_uscita);
                $('#desc').val(result.descrizione);
                $('#id_categoria').val(result.id_categoria);
                $(".mod").css({'visibility':'visible'});
            },
            error: function(response){
                alert(response);
            }
            
        });
}

function editgruppo(){    
        //e.preventDefault(); //blocca il submit
        
        var nomegruppo = $("#nomegruppo option:selected").text(); //recupera testo dentro l'opzione selezionata
        var nomegruppo = $.trim(nomegruppo); //rimuove spazi prima e dopo
        $.ajax({
            
            type:"POST",
            url:"edit-group-click.php",
            data:{ nomegruppo:nomegruppo }, //se sono più dati, separati da virgole (sx=php, dx=js)
            success: function(response){
                var result = JSON.parse(response);  //recuperare ciò che restituisce il php e interpretarlo
                //alert(result.id_categoria);  //accedi al campo desiderato
                $('#id').val(result.id_gruppo);
                $('#noome').val(result.nome); //sx: id input dx: nome database
                $('#desc').val(result.descrizione);
                $(".mod").css({'visibility':'visible'});
            },
            error: function(response){
                alert(response);
            }
            
        });
}

function editservizio(){    
        //e.preventDefault(); //blocca il submit
        
        var nomeservizio = $("#nomeservizio option:selected").text(); //recupera testo dentro l'opzione selezionata
        var nomeservizio = $.trim(nomeservizio); //rimuove spazi prima e dopo
        $.ajax({
            
            type:"POST",
            url:"edit-servizio-click.php",
            data:{ nomeservizio:nomeservizio }, //se sono più dati, separati da virgole (sx=php, dx=js)
            success: function(response){
                var result = JSON.parse(response);  //recuperare ciò che restituisce il php e interpretarlo
                //alert(result.id_categoria);  //accedi al campo desiderato
                $('#id').val(result.id_servizio);
                $('#scriipt').val(result.script); //sx: id input dx: nome database
                $('#desc').val(result.descrizione);
                $(".mod").css({'visibility':'visible'});
            },
            error: function(response){
                alert(response);
            }
            
        });
}

function edituser(){    
        //e.preventDefault(); //blocca il submit
        
        var nomeuser = $("#nomeuser option:selected").text(); //recupera testo dentro l'opzione selezionata
        var nomeuser = $.trim(nomeuser); //rimuove spazi prima e dopo
        $.ajax({
            
            type:"POST",
            url:"edit-user-click.php",
            data:{ nomeuser:nomeuser }, //se sono più dati, separati da virgole (sx=php, dx=js)
            success: function(response){
                var result = JSON.parse(response);  //recuperare ciò che restituisce il php e interpretarlo
                //alert(result.id_categoria);  //accedi al campo desiderato
                $('#id').val(result.id_utente);
                $('#useer').val(result.user); //sx: id input dx: nome database
                $('#pass').val(result.password);
                $('#eemail').val(result.email);
                $(".mod").css({'visibility':'visible'});
            },
            error: function(response){
                alert(response);
            }
            
        });
}

/*
function editgruppouser(){    
     var nomegruppouser = $("#nomegruppouser option:selected").text(); //recupera testo dentro l'opzione selezionata
        var nomegruppouser = $.trim(nomegruppouser); //rimuove spazi prima e dopo
        $.ajax({
            type:"POST",
            url:"edit-gruppo-user-click.php",
            data:{ nomegruppouser:nomegruppouser }, //se sono più dati, separati da virgole (sx=php, dx=js)
            success: function(response){
               // alert("qui");
                var result = JSON.parse(response);  //recuperare ciò che restituisce il php e interpretarlo
                //alert(result.id_categoria);  //accedi al campo desiderato
                $('#id_utente').val(result.id_utente);
                $('#id_gruppo').val(result.id_gruppo); //sx: id input dx: nome database
                $(".mod").css({'visibility':'visible'});
            },
            error: function(response){
                alert(response);
            }
            
        });
}
*/
    
    