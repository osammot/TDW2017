<?php

require("../include/dbms.inc.php");
require("../include/template2.inc.php");

$x = $_POST['nomeprodotto'];

$db->query("SELECT id_prodotto, nome, durata, distribuzione, formato, tipologia, regista, prezzo,      
                   quantita_disponibile, data_uscita, descrizione, id_categoria  
            FROM prodotti WHERE id_prodotto = '{$x}' ");

//SELECT `id_prodotto`, `nome`, `durata`, `distribuzione`, `formato`, `tipologia`, `regista`, `prezzo`, `quantita_disponibile`, `data_uscita`, `descrizione`, `id_categoria` FROM `prodotti` WHERE 1

$row = $db->getResult();

if($row!=false){
    echo json_encode($row[0]);  //per restituire al js la riga restiuita dalla query
}

?>